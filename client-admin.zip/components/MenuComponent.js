import React from 'react';
import { Link } from 'react-router-dom';

function MenuComponent() {
  return (
    <ul className="menu">
      <li className="menu">
        <Link to="/admin">Home</Link>
      </li>

      <li className="menu">
        <Link to="/admin/category">Category</Link>
      </li>
    </ul>
  );
}

export default MenuComponent;
