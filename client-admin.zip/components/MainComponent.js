import React from 'react';
import { Routes, Route } from 'react-router-dom';

import Home from './HomeComponent';
import Login from './LoginComponent';
import Category from './CategoryComponent';
import Menu from './MenuComponent';

function MainComponent() {
  return (
    <>
      <Menu />

      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<Home />} />
        <Route path="/admin/category" element={<Category />} />
      </Routes>
    </>
  );
}

export default MainComponent;
