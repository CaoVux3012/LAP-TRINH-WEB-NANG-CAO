import React, { useState, useContext } from 'react';
import axios from 'axios';
import MyContext from '../contexts/MyContext';
import { useNavigate } from 'react-router-dom';

function LoginComponent() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { setToken } = useContext(MyContext);
  const navigate = useNavigate();

  const login = async (e) => {
    e.preventDefault(); // ✅ CHẶN SUBMIT MẶC ĐỊNH (RẤT QUAN TRỌNG)

    try {
      const res = await axios.post(
        'http://localhost:3000/api/admin/login',
        { username, password }
      );

      console.log('LOGIN RESPONSE:', res.data); // 👈 DEBUG

      if (res.data.success) {
        localStorage.setItem('token', res.data.token);
        setToken(res.data.token);

        // ✅ KHÔNG reload app
        navigate('/admin');
      } else {
        alert(res.data.message);
      }
    } catch (err) {
      console.error('LOGIN ERROR:', err);
      alert('Cannot connect to server');
    }
  };

  return (
    <div>
      <h3>ADMIN LOGIN</h3>

      <form onSubmit={login}>
        <input
          placeholder="Username"
          value={username}
          onChange={e => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />

        <button type="submit">LOGIN</button>
      </form>
    </div>
  );
}

export default LoginComponent;
