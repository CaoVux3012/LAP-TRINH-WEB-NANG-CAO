const mongoose = require('mongoose');
const MyConstants = require('./MyConstants');

const password = encodeURIComponent(MyConstants.DB_PASS);

const uri =
  `mongodb+srv://${MyConstants.DB_USER}:${password}` +
  `@banhang.nuly8rn.mongodb.net/${MyConstants.DB_DATABASE}` +
  `?authSource=admin&retryWrites=true&w=majority&appName=banhang`;

mongoose
  .connect(uri)
  .then(() => {
    console.log('MongoDB connected successfully');
  })
  .catch(err => {
    console.error('MongoDB connection error:', err.message);
  });
