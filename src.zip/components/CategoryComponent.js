import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CategoryDetail from './CategoryDetailComponent';

function CategoryComponent() {
  const [categories, setCategories] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    const res = await axios.get('/api/admin/category');
    setCategories(res.data);
  };

  return (
    <div className="body-admin">
      <h2>CATEGORY LIST</h2>

      <table border="1">
        <tbody>
          <tr>
            <th>ID</th>
            <th>Name</th>
          </tr>
          {categories.map(c => (
            <tr key={c._id} onClick={() => setSelected(c)}>
              <td>{c._id}</td>
              <td>{c.name}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <CategoryDetail
        item={selected}
        reload={loadCategories}
      />
    </div>
  );
}

export default CategoryComponent;
