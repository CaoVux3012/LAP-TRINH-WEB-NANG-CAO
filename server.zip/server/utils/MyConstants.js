// module.exports = {
//   DB_USER: 'vu_db_ltnwc',
//   DB_PASS: 'PASSWORD_THẬT_TRONG_ATLAS',
//   DB_DATABASE: 'shoppingonline',

//   JWT_SECRET: 'lab02_secret_key',
//   JWT_EXPIRES: 3600000
// };
const MyConstants = {
  DB_SERVER: 'banhang.nuly8rn.mongodb.net', 
  DB_USER: 'vu_db_ltwnc',               
  DB_PASS: 'Hoangvu3012',               
  DB_DATABASE: 'shoppingonline',
  
  EMAIL_USER: 'email_user@hotmail.com', 
  EMAIL_PASS: 'email_pass',             
  
  JWT_SECRET: 'caothang', 
  JWT_EXPIRES: '3600000', 
};

module.exports = MyConstants;