import React, { Component } from 'react';
import MyContext from '../contexts/MyContext';
import Menu from './MenuComponent';
import Home from './HomeComponent';
import Category from './CategoryComponent'; // 1. Import Category
import { Routes, Route, Navigate } from 'react-router-dom'; // 2. Import thư viện Routing
import Login from './LoginComponent';

class Main extends Component {
  static contextType = MyContext; // using this.context to access global state
  render() {
    if (this.context.token !== '') {
      return (
        <div className="body-admin">
          <Menu />
          {/* 3. Thay thế thẻ <Home /> cũ bằng bộ <Routes> này */}
          <Routes>
            <Route path='/admin' element={<Navigate to='/admin/home' />} />
            <Route path='/admin/home' element={<Home />} />
            <Route path='/admin/category' element={<Category />} />
          </Routes>
        </div>
      );
    }
    return <Login />; // <--- SỬA THÀNH DÒNG NÀY
  }
}
export default Main;