import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
      <div className="align-center">
        <h2 className="text-center">ADMIN HOME</h2>
        <img
          src="https://media.giphy.com/media/JIX9t2j0ZTN9S/giphy.gif"
          alt="cat"
          style={{
            width: '400px',
            marginTop: '20px'
          }}
        />
      </div>
    );
  }
}
export default Home;