import React, { useEffect, useState } from 'react';
import axios from 'axios';

function CategoryDetail({ item, reload }) {
  const [id, setId] = useState('');
  const [name, setName] = useState('');

  useEffect(() => {
    if (item) {
      setId(item._id);
      setName(item.name);
    }
  }, [item]);

  const add = async () => {
    try {
      await axios.post('/api/admin/categories', { name });
      alert('ADD SUCCESS');
      reload();
    } catch {
      alert('ADD FAILED');
    }
  };

  const update = async () => {
    await axios.put(`/api/admin/categories/${id}`, { name });
    reload();
  };

  const remove = async () => {
    await axios.delete(`/api/admin/categories/${id}`);
    reload();
  };

  return (
    <>
      <h2>CATEGORY DETAIL</h2>
      ID <input value={id} disabled /><br />
      Name <input value={name} onChange={e => setName(e.target.value)} /><br />
      <button onClick={add}>ADD NEW</button>
      <button onClick={update}>UPDATE</button>
      <button onClick={remove}>DELETE</button>
    </>
  );
}

export default CategoryDetail;
