// File: server/models/CategoryDAO.js
require('../utils/MongooseUtil');
const Models = require('./Models');

const CategoryDAO = {
  // 1. Lấy tất cả danh mục
  async selectAll() {
    const query = {};
    const categories = await Models.Category.find(query).exec();
    return categories;
  },
  // 2. Thêm danh mục mới
  async insert(category) {
    const mongoose = require('mongoose');
    category._id = new mongoose.Types.ObjectId();
    const result = await Models.Category.create(category);
    return result;
  },
  // 3. Cập nhật danh mục
  async update(category) {
    const newvalues = { name: category.name };
    const result = await Models.Category.findByIdAndUpdate(category._id, newvalues, { new: true });
    return result;
  },
  // 4. Xóa danh mục
  async delete(_id) {
    const result = await Models.Category.findByIdAndDelete(_id);
    return result;
  }
};
module.exports = CategoryDAO;