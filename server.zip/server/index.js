// const express = require('express');
// const bodyParser = require('body-parser');

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));

// app.get('/hello', (req, res) => {
//   res.json({ message: 'Hello from server!' });
// });

// app.listen(PORT, () => {
//   console.log(`Server listening on ${PORT}`);
// });

// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');

// // connect mongo
// require('./utils/MongooseUtil');

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(cors());
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));

// // test route
// app.get('/hello', (req, res) => {
//   res.json({ message: 'Hello from server!' });
// });

// // admin api
// app.use('/api/admin', require('./api/admin'));

// app.listen(PORT, () => {
//   console.log(`Server listening on ${PORT}`);
// });

const express = require('express');
const cors = require('cors');

// connect mongo
require('./utils/MongooseUtil');

const app = express();
const PORT = 3000;

// ===== MIDDLEWARE BẮT BUỘC =====
app.use(cors());
app.use(express.json()); // ✅ để đọc req.body (ADD / UPDATE)
app.use(express.urlencoded({ extended: true }));

// ===== TEST API =====
app.get('/hello', (req, res) => {
  res.json({ message: 'Hello from server!' });
});

// ===== ADMIN API =====
// mount đúng prefix /api/admin
app.use('/api/admin', require('./api/admin'));

// ===== START SERVER =====
app.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});
